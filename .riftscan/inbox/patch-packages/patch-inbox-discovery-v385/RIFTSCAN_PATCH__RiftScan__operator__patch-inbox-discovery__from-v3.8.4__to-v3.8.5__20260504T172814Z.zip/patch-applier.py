# Version: riftscan-operator-patch-inbox-discovery-repair-applier-v1.0
# Purpose: Repair the RiftScan Operator patch inbox discovery button by inserting it directly into the native Main tab grid and neutralizing the failed dynamic injection. This applier does not create services, listeners, polling, package download, extraction, staging, patch application, auto-commit, auto-push, or git add behavior.
# Total character count: 8781

from __future__ import annotations

import argparse
import datetime as dt
import py_compile
import re
from pathlib import Path


TARGET_APP_VERSION = "riftscan-operator-app-v3.8.5"
DEFAULT_REPO_ROOT = Path(r"C:\RIFT MODDING\Riftscan")
NATIVE_BUTTON_MARKER = "# v3.8.5 native Main-tab repair: visible discovery-only inbox button."


def utc_stamp() -> str:
    return dt.datetime.now(dt.UTC).strftime("%Y%m%dT%H%M%SZ")


def resolve_repo_root(raw: str | None) -> Path:
    if raw:
        return Path(raw).expanduser().resolve()

    cwd = Path.cwd().resolve()
    if (cwd / "tools" / "riftscan_operator_app.py").exists():
        return cwd

    return DEFAULT_REPO_ROOT


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def find_operator_class_name(text: str) -> str:
    assignment_match = re.search(
        r"^([A-Za-z_][A-Za-z0-9_]*)\.check_online_patch_inbox\s*=\s*_riftscan_check_online_patch_inbox\s*$",
        text,
        flags=re.MULTILINE,
    )
    if assignment_match:
        return assignment_match.group(1)

    preferred = re.search(r"^class\s+(RiftScanOperatorApp)\s*\(", text, flags=re.MULTILINE)
    if preferred:
        return preferred.group(1)

    candidates = re.findall(r"^class\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", text, flags=re.MULTILINE)
    for name in candidates:
        if "Operator" in name or "RiftScan" in name:
            return name

    raise RuntimeError("Could not locate the Operator class name.")


def patch_main_tab_button_grid(text: str) -> str:
    if NATIVE_BUTTON_MARKER in text:
        return text

    pattern = re.compile(
        r"(?P<head>self\.add_button_grid\(\s*main_tab,\s*\[\n)"
        r"(?P<body>.*?)(?P<tail>\n\s*\],\s*\n\s*columns=3,\s*\n\s*\))",
        flags=re.DOTALL,
    )

    matches = list(pattern.finditer(text))
    require(matches, "Could not locate self.add_button_grid(main_tab, [...], columns=3).")

    target_match = None
    for match in matches:
        body = match.group("body")
        if '"Refresh Status"' in body and '"Open Report"' in body:
            target_match = match
            break

    if target_match is None:
        for match in matches:
            if '"Refresh Status"' in match.group("body"):
                target_match = match
                break

    require(target_match is not None, "Could not identify the native Main tab button grid.")

    body = target_match.group("body")
    if '"Check Online Patch Inbox"' in body:
        repaired_body = body
    else:
        refresh_line = re.search(
            r'(?P<line>^(?P<indent>\s*)\("Refresh Status", self\.refresh_status\),\s*$)',
            body,
            flags=re.MULTILINE,
        )
        require(refresh_line is not None, "Could not locate Refresh Status tuple inside Main tab grid.")

        indent = refresh_line.group("indent")
        insertion = (
            f"\n{indent}{NATIVE_BUTTON_MARKER}\n"
            f'{indent}("Check Online Patch Inbox", self.check_online_patch_inbox),'
        )
        repaired_body = body[: refresh_line.end()] + insertion + body[refresh_line.end() :]

    start, end = target_match.span("body")
    return text[:start] + repaired_body + text[end:]


def neutralize_dynamic_injection(text: str, class_name: str) -> str:
    function_name = "def _riftscan_operator_init_with_patch_inbox"
    if function_name not in text:
        return text

    if "dynamic UI injection is intentionally disabled" in text:
        return text

    start = text.find(function_name)
    end_marker = f"\n\n{class_name}.check_online_patch_inbox = _riftscan_check_online_patch_inbox"
    end = text.find(end_marker, start)
    require(end != -1, "Could not locate end of dynamic __init__ patch block.")

    replacement = '''def _riftscan_operator_init_with_patch_inbox(self: Any, *args: Any, **kwargs: Any) -> None:
    _original_riftscan_operator_init(self, *args, **kwargs)
    # v3.8.5: native Main-tab button is inserted in __init__; dynamic UI injection is intentionally disabled.
    try:
        self._patch_inbox_button_added = True
    except Exception:
        pass
'''

    return text[:start] + replacement + text[end:]


def ensure_v384_discovery_workflow_present(text: str) -> None:
    require(
        "RIFTSCAN PATCH INBOX DISCOVERY V384 PATCH START" in text,
        "v3.8.4 patch block is missing. Apply v3.8.4 before this repair.",
    )
    require(
        "_riftscan_check_online_patch_inbox" in text,
        "Existing discovery-only workflow method is missing.",
    )
    require(
        "discover_patch_inbox" in text,
        "Existing discovery-only inbox scanner is missing.",
    )


def update_header_and_version(text: str) -> str:
    purpose = (
        "# Purpose: Windows Tkinter helper app for RiftScan operator workflow: run focus preflight, "
        "run full live preflight gate, manage focus-gated metadata workflows, validate patch-runner manifests, "
        "check the online patch inbox discovery-only from the visible Main tab, write compact AI-ready reports, "
        "clean known junk, safely commit/push allowlisted files, and provide tabbed/wrapped controls with lightweight status highlighting."
    )

    text = re.sub(r"^# Version: .*$", f"# Version: {TARGET_APP_VERSION}", text, count=1, flags=re.MULTILINE)
    text = re.sub(r"^# Purpose: .*$", purpose, text, count=1, flags=re.MULTILINE)
    text = re.sub(r'^APP_VERSION = ".*?"$', f'APP_VERSION = "{TARGET_APP_VERSION}"', text, count=1, flags=re.MULTILINE)

    if "# End of script" not in text:
        text = text.rstrip() + "\n\n# End of script\n"

    for _ in range(10):
        new_text = re.sub(
            r"^# Total character count: \d+",
            f"# Total character count: {len(text)}",
            text,
            count=1,
            flags=re.MULTILINE,
        )
        if new_text == text:
            return text
        text = new_text

    return text


def patch_operator_app(source: str) -> str:
    ensure_v384_discovery_workflow_present(source)
    class_name = find_operator_class_name(source)

    text = source
    text = patch_main_tab_button_grid(text)
    text = neutralize_dynamic_injection(text, class_name)
    text = update_header_and_version(text)
    return text


def main() -> int:
    parser = argparse.ArgumentParser(description="Repair RiftScan Operator patch inbox discovery Main-tab button.")
    parser.add_argument("--repo-root", default=None, help=r"Path to RiftScan repo root. Defaults to current directory or C:\RIFT MODDING\Riftscan.")
    args = parser.parse_args()

    repo_root = resolve_repo_root(args.repo_root)
    operator_path = repo_root / "tools" / "riftscan_operator_app.py"
    require(operator_path.exists(), f"Missing Operator app: {operator_path}")

    source = operator_path.read_text(encoding="utf-8", errors="replace")
    patched = patch_operator_app(source)

    if patched == source:
        print("No changes needed. Native Main-tab patch inbox button repair already appears to be present.")
        return 0

    backup_dir = repo_root / ".riftscan-local" / "patch-backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    backup_path = backup_dir / f"riftscan_operator_app.py.bak-{utc_stamp()}-pre-v385"
    backup_path.write_text(source, encoding="utf-8")

    operator_path.write_text(patched, encoding="utf-8")
    py_compile.compile(str(operator_path), doraise=True)

    print("PATCH APPLIED: Operator patch inbox discovery Main-tab repair v3.8.5")
    print(f"Repo root : {repo_root}")
    print(f"Modified  : {operator_path}")
    print(f"Backup    : {backup_path}")
    print("")
    print("Behavior:")
    print("- Adds Check Online Patch Inbox directly to the native Main tab grid")
    print("- Reuses the existing v3.8.4 discovery-only workflow")
    print("- Neutralizes the failed dynamic button injection")
    print("")
    print("Intentionally not implemented:")
    print("- no service")
    print("- no listener")
    print("- no polling")
    print("- no package download")
    print("- no extraction")
    print("- no staging")
    print("- no dry-run apply")
    print("- no real apply")
    print("- no auto-commit")
    print("- no auto-push")
    print("- no git add .")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# End of script
