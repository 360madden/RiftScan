@echo off
setlocal
REM Version: riftscan-patch-run-me-first-v1
REM Purpose: Run the local RiftScan patch applier from this extracted package only.
REM Total character count: 764

set "REPO_ROOT=C:\RIFT MODDING\Riftscan"
set "PKG_DIR=%~dp0"
set "APPLIER=%PKG_DIR%patch-applier.py"
set "MANIFEST=%PKG_DIR%RIFTSCAN_PATCH_PACKAGE.json"

echo === RiftScan patch package runner ===
echo Repo root: %REPO_ROOT%
echo Package  : %PKG_DIR%
echo.

if not exist "%MANIFEST%" (
  echo FAIL_MISSING_MANIFEST: %MANIFEST%
  exit /b 1
)

if not exist "%APPLIER%" (
  echo FAIL_APPLIER_MISSING: %APPLIER%
  exit /b 1
)

python "%APPLIER%" --repo-root "%REPO_ROOT%"
if errorlevel 1 (
  echo FAIL_APPLIER_RUNTIME
  exit /b 1
)

echo PASS_APPLIER_FINISHED
exit /b 0

REM End of script
