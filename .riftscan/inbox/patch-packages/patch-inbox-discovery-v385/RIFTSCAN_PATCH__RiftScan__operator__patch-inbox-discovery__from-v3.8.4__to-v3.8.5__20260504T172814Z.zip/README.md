# RiftScan Exact Timestamped ZIP Patch Package

Package filename:

```text
RIFTSCAN_PATCH__RiftScan__operator__patch-inbox-discovery__from-v3.8.4__to-v3.8.5__20260504T172814Z.zip
```

This package follows the RiftScan Exact Timestamped ZIP Intake standard.

## Contents

```text
RUN_ME_FIRST.cmd
RIFTSCAN_PATCH_PACKAGE.json
patch-applier.py
README.md
```

## Target

```text
Repo: C:\RIFT MODDING\Riftscan
Target file: tools/riftscan_operator_app.py
From: riftscan-operator-app-v3.8.4
To:   riftscan-operator-app-v3.8.5
```

## Safety boundaries

```text
no git add .
no auto-commit
no auto-push
no force-push
no service
no listener
no polling
no scheduled task
no arbitrary shell commands from manifest
```

## Original README content

# RiftScan Operator Patch Inbox Discovery v3.8.5 Repair

Repairs v3.8.4 by inserting the button directly into the native **Main** tab button grid.

## Fix

Adds this visible Main-tab button:

```text
Check Online Patch Inbox
```

It reuses the existing v3.8.4 discovery-only workflow.

It also neutralizes the failed dynamic button injection so startup no longer depends on runtime UI discovery.

## Scope boundaries

Not implemented:

```text
no service
no listener
no polling
no package download
no extraction
no staging
no dry-run apply
no real apply
no auto-commit
no auto-push
no git add .
```

## Extract + run

From PowerShell:

```powershell
cd "$env:USERPROFILE\Downloads"

$Zip = ".\RiftScan_Operator_Patch_Inbox_Discovery_v385.zip"
$ExtractDir = ".\RiftScan_Operator_Patch_Inbox_Discovery_v385"

Remove-Item -Recurse -Force $ExtractDir -ErrorAction SilentlyContinue
Expand-Archive -LiteralPath $Zip -DestinationPath $ExtractDir -Force

cd $ExtractDir
.\apply-riftscan-operator-patch-inbox-discovery-v385.cmd
```

## Launch patched repo Operator directly

```powershell
cd "C:\RIFT MODDING\Riftscan"
python ".\tools\riftscan_operator_app.py"
```

## Expected GUI result

On the **Main** tab, the visible buttons should include:

```text
Refresh Status
Check Online Patch Inbox
Run Window/Process Metadata Collector
Analyze Latest Session
Compare Sessions
Open Report
```

## Test button

Click:

```text
Check Online Patch Inbox
```

Expected result if the inbox folder does not exist:

```text
PATCH INBOX DISCOVERY: PASS/EMPTY
Empty reason: inbox_path_missing
```

## Expected git status after applying, before clicking button

```text
M tools/riftscan_operator_app.py
?? .riftscan-local/
```

Possibly:

```text
?? tools/__pycache__/
```

Remove cache if present:

```powershell
Remove-Item -Recurse -Force "C:\RIFT MODDING\Riftscan\tools\__pycache__" -ErrorAction SilentlyContinue
```

## Expected git status after clicking button

```text
M tools/riftscan_operator_app.py
M handoffs/current/operator/RIFTSCAN_OPERATOR_HANDOFF.md
?? .riftscan-local/
?? handoffs/current/repo-bridge/patch-inbox-discovery-result.json
```

## Commit safely

```powershell
cd "C:\RIFT MODDING\Riftscan"
git add tools/riftscan_operator_app.py handoffs/current/operator handoffs/current/repo-bridge
git commit -m "Add patch inbox discovery to operator app"
git push
```

Do not use:

```powershell
git add .
```

# End of document


# End of document
