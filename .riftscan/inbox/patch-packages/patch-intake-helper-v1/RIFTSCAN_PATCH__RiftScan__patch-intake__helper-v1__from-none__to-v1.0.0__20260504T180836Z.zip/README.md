# RiftScan Patch Intake Helper v1

Adds:

```text
tools/riftscan_patch_intake_app.py
scripts/riftscan-patch-intake.cmd
```

## Behavior

- Always-on-top GUI paste box.
- Headless CLI modes: `--self-test`, `--validate-file`, `--dry-run-file`, `--apply-file`.
- Validates `RIFTSCAN_CLIPBOARD_PATCH_V1` machine-readable patch payloads.
- Supports `python_applier_base64_gzip` payloads.
- Applies only through explicit `--apply-file` or GUI `Apply Patch` button.

## Blocked

```text
no clipboard watcher
no service
no listener
no polling
no git add .
no auto-commit
no auto-push
no force-push
```

## Smoke tests

```powershell
python -m py_compile .\tools\riftscan_patch_intake_app.py
python .\tools\riftscan_patch_intake_app.py --self-test
.\scripts\riftscan-patch-intake.cmd --self-test
```

# End of document
