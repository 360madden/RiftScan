@echo off
setlocal
REM Version: riftscan-patch-intake-helper-v1-runner
REM Purpose: Run patch-applier.py from this extracted package.
REM Total character count: 434

set "REPO_ROOT=C:\RIFT MODDING\Riftscan"
set "PKG_DIR=%~dp0"
set "APPLIER=%PKG_DIR%patch-applier.py"

if not exist "%APPLIER%" (
  echo FAIL_APPLIER_MISSING: %APPLIER%
  exit /b 1
)

python "%APPLIER%" --repo-root "%REPO_ROOT%"
exit /b %ERRORLEVEL%

REM End of script
