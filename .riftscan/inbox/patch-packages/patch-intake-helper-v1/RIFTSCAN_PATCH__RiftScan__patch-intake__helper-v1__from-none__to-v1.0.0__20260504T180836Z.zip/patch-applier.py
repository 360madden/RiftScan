# Version: riftscan-patch-intake-helper-v1-applier
# Purpose: Install RiftScan Patch Intake Helper v1 files into the local repo and run compile/self-test smoke checks. No git add, no commit, no push, no service, no listener, no polling.
# Total character count: 2006

from __future__ import annotations

import argparse
import py_compile
import shutil
import subprocess
import sys
from pathlib import Path


PACKAGE_DIR = Path(__file__).resolve().parent


def run(args: list[str], cwd: Path) -> tuple[int, str, str]:
    completed = subprocess.run(args, cwd=str(cwd), capture_output=True, text=True, shell=False)
    return completed.returncode, completed.stdout, completed.stderr


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", required=True)
    args = parser.parse_args()

    repo_root = Path(args.repo_root).resolve()
    source_tool = PACKAGE_DIR / "payload" / "tools" / "riftscan_patch_intake_app.py"
    source_cmd = PACKAGE_DIR / "payload" / "scripts" / "riftscan-patch-intake.cmd"
    target_tool = repo_root / "tools" / "riftscan_patch_intake_app.py"
    target_cmd = repo_root / "scripts" / "riftscan-patch-intake.cmd"

    if not source_tool.exists():
        print(f"FAIL_SOURCE_MISSING: {source_tool}")
        return 1
    if not source_cmd.exists():
        print(f"FAIL_SOURCE_MISSING: {source_cmd}")
        return 1

    target_tool.parent.mkdir(parents=True, exist_ok=True)
    target_cmd.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source_tool, target_tool)
    shutil.copy2(source_cmd, target_cmd)

    py_compile.compile(str(target_tool), doraise=True)

    code, out, err = run([sys.executable, str(target_tool), "--self-test"], cwd=repo_root)
    print(out)
    if err:
        print(err, file=sys.stderr)
    if code != 0:
        print("FAIL_SELF_TEST")
        return code

    print("PASS_APPLIED_PATCH_INTAKE_HELPER_V1")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# End of script
